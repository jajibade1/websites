<script>
alert("Hello");
document.write("Hello");
</script>